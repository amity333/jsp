package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Customer;
import com.cg.dto.CustomerBill;
import com.cg.service.CustomerService;
import com.cg.service.CustomerServiceImpl;

/**
 * Servlet implementation class ebillServlet
 */
@WebServlet("/ebillServlet")
public class ebillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    CustomerService service;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ebillServlet() {
        super();
        service=new  CustomerServiceImpl();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(true);
		String qstr=request.getParameter("action");
		System.out.println("Hellodoget");
		if(qstr.equals("CustomerList"))
		{
			System.out.println("inside doget if");
			ArrayList<Customer> list=service.getAllCustomer();
			session.setAttribute("cust", list);
			
			RequestDispatcher dispatch=request.getRequestDispatcher("searchAll.jsp");
			dispatch.forward(request,  response);
			
		}
		else if(qstr.equals("SearchCustomer"))
		{
			
			RequestDispatcher dispatch=request.getRequestDispatcher("search.jsp");
			dispatch.forward(request,  response);
		}
		else if(qstr.equals("generateBill"))
		{
			int id=Integer.parseInt(request.getParameter("id"));
			session.setAttribute("id", id);
			RequestDispatcher dispatch=request.getRequestDispatcher("Bill.jsp");
			dispatch.forward(request,  response);
		}
		else if(qstr.equals("showBill"))
		{
			
			int id1=Integer.parseInt(request.getParameter("id"));
			session.setAttribute("id", id1);
			ArrayList<CustomerBill> cb=service.getAllBill(id1);
			if(cb!=null)
			{
			System.out.println("Fuuuuuuck");
			session.setAttribute("bill", cb);
			RequestDispatcher dispatch=request.getRequestDispatcher("ShowBill.jsp");
			dispatch.forward(request,  response);
			}
			else
			{
				System.out.println("Ohhhh aaahh");
				System.out.println("bill not find");
				Customer c=service.getCustomerById(id1);
				session.setAttribute("name", c);
				RequestDispatcher dispatch=request.getRequestDispatcher("billNotPresent.jsp");
				dispatch.forward(request,  response);
			}
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(false);
		String qstr=request.getParameter("action");
		if(qstr.equals("searchById"))
		{
			int id=Integer.parseInt(request.getParameter("id"));
			Customer cust=service.getCustomerById(id);
			session.setAttribute("cust", cust);
			RequestDispatcher dispatch=request.getRequestDispatcher("searchSuccess.jsp");
			dispatch.forward(request,  response);
		}
		else if(qstr.equals("insertbill"))
		{
			
			int id=Integer.parseInt(request.getParameter("id"));
			double lmr=Double.parseDouble(request.getParameter("lm"));
			double cmr=Double.parseDouble(request.getParameter("cm"));
			double reading=cmr-lmr;
			double amt=reading*1.15+100;
			
			CustomerBill cbill=new CustomerBill();
			cbill.setId(id);
			cbill.setBillAmount(amt);
			cbill.setMeterReading(cmr);
			cbill.setUnitConsumed(reading);
			CustomerBill ref=service.addBill(id, cbill);
			ArrayList<CustomerBill> cb=service.getAllBill(id);
			if(ref!=null)
			{
				System.out.println("hello");
				session.setAttribute("bill", cb);
				RequestDispatcher dispatch =	request.getRequestDispatcher("ShowBill.jsp");
		    	dispatch.forward(request, response);
			}
			
		}
	}

}
