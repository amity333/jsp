package com.cg.service;

import java.util.ArrayList;

import com.cg.DAO.CustomerDaoImpl;
import com.cg.dto.Customer;
import com.cg.dto.CustomerBill;

public class CustomerServiceImpl implements CustomerService
{
CustomerDaoImpl dao=new CustomerDaoImpl();
	
	@Override
	public ArrayList<Customer> getAllCustomer() {
		return dao.getAllCustomer();
	}

	@Override
	public Customer getCustomerById(int id) {
		// TODO Auto-generated method stub
		return dao.getCustomerById(id);
	}

	@Override
	public CustomerBill addBill(int id, CustomerBill cbill) {
		// TODO Auto-generated method stub
		return dao.addBill(id, cbill);
	}

	@Override
	public ArrayList<CustomerBill> getAllBill(int id) {
		// TODO Auto-generated method stub
		return dao.getAllBill(id);
	}

}
