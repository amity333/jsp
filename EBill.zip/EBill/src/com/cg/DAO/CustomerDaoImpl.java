package com.cg.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.UTIL.DBUtil;
import com.cg.UTIL.MyStringDateUtil;
import com.cg.dto.Customer;
import com.cg.dto.CustomerBill;

public class CustomerDaoImpl implements CustomerDao
{
	Connection con;
	public CustomerDaoImpl()
	{
		con=DBUtil.getConnection();
	}
	
	@Override
	public ArrayList<Customer> getAllCustomer() 
	{
		String qry="select * from Consumers";
		ArrayList<Customer> list=new ArrayList<Customer>();
		try {
			System.out.println("inside try of getAll");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(qry);
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				String addr=rs.getString(3);
				Customer c=new Customer(id,name,addr);
				list.add(c);
				System.out.println("yes");
			}
			if(list!=null)
			{
				System.out.println("Not null");
			}
			else System.out.println("Null");
			return list;
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Customer getCustomerById(int id) {
		
		Customer cust=null;
		String qry="Select * from Consumers where  consumer_num=?";
		try 
		{	
			PreparedStatement pst=con.prepareStatement(qry);
			pst.setInt(1,id);
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				String name=rs.getString(2);
				String addr=rs.getString(3);
				cust=new Customer(id, name,addr);
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cust;
	}

	@Override
	public CustomerBill addBill(int id , CustomerBill cbill)
	{
		 String qry="Insert into BillDetails values(seq_bill_num.nextval,?,?,?,?,sysdate)";
		try
		{
			PreparedStatement pst=con.prepareStatement(qry);
			pst.setInt(1, id);
			pst.setDouble(2, cbill.getMeterReading());
			pst.setDouble(3, cbill.getUnitConsumed());
			pst.setDouble(4, cbill.getBillAmount());
			int row=pst.executeUpdate();
			if(row>0)
			{
				System.out.println("bill added successfully");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return cbill;
	}

	@Override
	public ArrayList<CustomerBill> getAllBill(int id)
	{
		String qry="select * from BillDetails where consumer_num=?";
		ArrayList<CustomerBill> list=new ArrayList<CustomerBill>();
		try {
			PreparedStatement pst=con.prepareStatement(qry);
			pst.setInt(1,id);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				int bnum=rs.getInt(1);
				int cid=rs.getInt(2);
				double cr=rs.getDouble(3);
				double cunit=rs.getDouble(4);
				double amt=rs.getDouble(5);
				LocalDate ld=MyStringDateUtil.fromSqlToLocalDate(rs.getDate(6));		
				CustomerBill cbill=new CustomerBill(bnum, cid, ld,cr, cunit, amt);
				list.add(cbill);
			}
			if(list.size()==0){
				list=null;
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

}
