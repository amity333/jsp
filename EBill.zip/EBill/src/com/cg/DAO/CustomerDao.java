/**
 * 
 */
package com.cg.DAO;

import java.util.ArrayList;

import com.cg.dto.Customer;
import com.cg.dto.CustomerBill;

/**
 * @author pardubey
 *
 */
public interface CustomerDao {

public ArrayList<Customer> getAllCustomer();
public Customer getCustomerById(int id);
public CustomerBill addBill(int id, CustomerBill cbill);
public ArrayList<CustomerBill> getAllBill(int id);
}
