package com.cg.dto;

import java.time.LocalDate;

public class CustomerBill
{
	int billNumber;
	int id;
	LocalDate billdate;
	double meterReading;
	double unitConsumed;
	double billAmount;
	
	public CustomerBill()
	{}
	@Override
	public String toString() {
		return "CustomerBill [billNumber=" + billNumber + ", id=" + id
				+ ", billdate=" + billdate + ", meterReading=" + meterReading
				+ ", unitConsumed=" + unitConsumed + ", billAmount="
				+ billAmount + "]";
	}
	public int getBillNumber() {
		return billNumber;
	}
	public void setBillNumber(int billNumber) {
		this.billNumber = billNumber;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public LocalDate getBilldate() {
		return billdate;
	}
	public void setBilldate(LocalDate billdate) {
		this.billdate = billdate.now();
	}
	public double getMeterReading() {
		return meterReading;
	}
	public void setMeterReading(double meterReading) {
		this.meterReading = meterReading;
	}
	public double getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public double getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	}
	public CustomerBill(int billNumber, int id, LocalDate billdate,
			double meterReading, double unitConsumed, double billAmount) {
		super();
		this.billNumber = billNumber;
		this.id = id;
		this.billdate = billdate;
		this.meterReading = meterReading;
		this.unitConsumed = unitConsumed;
		this.billAmount = billAmount;
	}
}