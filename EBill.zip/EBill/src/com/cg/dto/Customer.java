package com.cg.dto;

public class Customer {
 int id;
 String name;
 String addr;
public Customer(int id, String name, String addr) {
	super();
	this.id = id;
	this.name = name;
	this.addr = addr;
}

public Customer() {}

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddr() {
	return addr;
}
public void setAddr(String addr) {
	this.addr = addr;
}
@Override
public String toString() {
	return "Customer [id=" + id + ", name=" + name + ", addr=" + addr + "]";
}

}
