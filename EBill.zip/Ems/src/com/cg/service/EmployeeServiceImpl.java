package com.cg.service;

import java.util.ArrayList;

import com.cg.DAO.EmployeeDao;
import com.cg.DAO.EmployeeDaoImpl;
import com.cg.DTO.Employee;

public class EmployeeServiceImpl  implements EmployeeService
{
	EmployeeDao dao;
	public EmployeeServiceImpl()
	{
		this.dao=new EmployeeDaoImpl();
	}
	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return dao.addEmployee(emp);
	}
	@Override
	public Employee getEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return dao.getEmployeeById(empId);
	}
	@Override
	public ArrayList<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return dao.getAllEmployees();
	}
	@Override
	public void delete(int eid) {
		dao.delete(eid);
		
		
	}
	@Override
	public void update(Employee emp) 
	{
		dao.update(emp);
	}
}
