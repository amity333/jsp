package com.cg.service;

import java.util.ArrayList;

import com.cg.DTO.Employee;

public interface EmployeeService {
	public Employee  addEmployee(Employee emp);
	public Employee  getEmployeeById(int empId);
	public ArrayList<Employee> getAllEmployees();
	public void delete(int eid);
	public void update(Employee emp);

}
