package com.cg.DAO;

import java.util.ArrayList;

import com.cg.DTO.Employee;

public interface EmployeeDao {
	
	public Employee  addEmployee(Employee emp);
	public Employee  getEmployeeById(int empId);
	public void delete(int eid);
	public ArrayList<Employee> getAllEmployees();
	public void update(Employee emp); 
}
