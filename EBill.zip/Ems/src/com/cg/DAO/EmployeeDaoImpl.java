package com.cg.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.ResultSet;

import com.cg.DTO.Employee;
import com.cg.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao
{
	Connection con;
	public EmployeeDaoImpl()
	{
		con=DBUtil.getConnection();
	}
	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		
		 Employee ref=null;
		 String qry="Insert into EmpDetails values(eid_seq.nextval,?,?,?)";
		try
		{
			PreparedStatement pst=con.prepareStatement(qry);
			pst.setString(1, emp.getEmpName());
			pst.setInt(2, emp.getEmpSal());
			pst.setString(3, emp.getEmpAddr());
			int row=pst.executeUpdate();
			if(row>0)
			{
				emp.setEmpId(getEmployeeId());
				ref=emp;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ref;
	}
	public int getEmployeeId()
	{
		int id=0;
		String qry="Select eid_seq.currval From Dual";
		
		try{
			Statement st=con.createStatement();
			java.sql.ResultSet rs= st.executeQuery(qry);
			if(rs.next())
			{
				id=rs.getInt(1);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return id;
	}
	
	
	@Override
	public Employee getEmployeeById(int empId) {
		Employee ref=null;
		String qry="Select* from empdetails where empId=?";
		try
		{
			PreparedStatement pst=con.prepareStatement(qry);
			pst.setInt(1, empId);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				int sal=rs.getInt(3);
				String addr=rs.getString(4);
				ref=new Employee(id, name, sal, addr);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ref;
	}
	@Override
	public ArrayList<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		String qry="Select  * from EmpDetails";
		ArrayList<Employee> list=new ArrayList<Employee>();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(qry);
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				int sal=rs.getInt(3);
				String addr=rs.getString(4);
				Employee emp = new Employee(id,name,sal,addr);
				list.add(emp);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}
	@Override
	public void delete(int eid) {
		
		String qry="Delete from EmpDetails where empId=?";
		try 
		{
			PreparedStatement pst=con.prepareStatement(qry);
			pst.setInt(1, eid);
			pst.executeUpdate();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	}
	@Override
	public void update(Employee emp) {
		
		String qry="Update EmpDetails set empName=?,  empAddr=?,  empSal=? where empId=?";
		try 
		{
			PreparedStatement pst=con.prepareStatement(qry);
			pst.setString(1, emp.getEmpName());
			pst.setString(2, emp.getEmpAddr());
			pst.setInt(3, emp.getEmpSal());
			pst.setInt(4, emp.getEmpId());
			pst.executeUpdate();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
	}
}
